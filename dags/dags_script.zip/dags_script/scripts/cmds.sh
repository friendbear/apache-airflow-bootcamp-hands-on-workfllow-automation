#! /bin/bash
# print hello from BashOperator message
echo "Hello from BashOperator"